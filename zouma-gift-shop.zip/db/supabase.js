import { createClient } from "@supabase/supabase-js";
import fs from "fs";
import path from "path";
import crypto from "crypto";

export const isProductionDb = !!(process.env.SUPABASE_URL && process.env.SUPABASE_KEY);

let supabaseClient = null;

if (isProductionDb) {
  try {
    supabaseClient = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_KEY);
    console.log("Supabase Client initialized successfully via @supabase/supabase-js");
  } catch (err) {
    console.error("Failed to initialize Supabase Client:", err);
  }
}

// Fallback JSON-file database helpers for local mode
const fallbackDbPath = path.resolve(process.cwd(), "db", "zouma_db.json");

function initFallbackDb() {
  const dir = path.dirname(fallbackDbPath);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }

  if (fs.existsSync(fallbackDbPath)) {
    try {
      const content = fs.readFileSync(fallbackDbPath, "utf-8");
      return JSON.parse(content);
    } catch (e) {
      console.error("Failed to parse JSON DB, regenerating typical skeleton...", e);
    }
  }

  const defaultAdminPasswordHash = "$2a$10$Wpkyg043mC66A4T.v17m1ugkP6a5P0O9Sskp6kIieQy/Q0U5L0s0K"; // admin123

  const freshDb = {
    clients: [
      {
        id: "c1111111-2222-3333-4444-555555555555",
        name: "حسن رجب (أحمد)",
        phone: "01012345678",
        phone2: "01187654321",
        address: "القاهرة، مصر",
        client_code: "9382",
        dob: "1994-08-20",
        created_at: new Date(Date.now() - 30 * 24 * 3600 * 1000).toISOString()
      },
      {
        id: "c2222222-2222-3333-4444-555555555555",
        name: "أميرة محمد",
        phone: "01234567890",
        address: "الجيزة، الدقي",
        client_code: "1140",
        dob: "1998-05-12",
        created_at: new Date(Date.now() - 15 * 24 * 3600 * 1000).toISOString()
      }
    ],
    products: [
      {
        id: "p1111111-2222-3333-4444-555555555555",
        serial: 1001,
        name: "دبدوب أحمر كبير مخملي",
        wholesale_price: 150,
        selling_price: 250,
        stock: 12,
        created_at: new Date(Date.now() - 30 * 24 * 3600 * 1000).toISOString()
      },
      {
        id: "p2222222-2222-3333-4444-555555555555",
        serial: 1002,
        name: "صندوق هدايا خشبي محفور",
        wholesale_price: 80,
        selling_price: 160,
        stock: 5,
        created_at: new Date(Date.now() - 28 * 24 * 3600 * 1000).toISOString()
      },
      {
        id: "p3333333-2222-3333-4444-555555555555",
        serial: 1003,
        name: "سلسلة فضية بتصميم خاص",
        wholesale_price: 300,
        selling_price: 480,
        stock: 8,
        created_at: new Date(Date.now() - 20 * 24 * 3600 * 1000).toISOString()
      },
      {
        id: "p4444444-2222-3333-4444-555555555555",
        serial: 1004,
        name: "كوب حراري ذكي مع شاشة حرارة",
        wholesale_price: 90,
        selling_price: 180,
        stock: 20,
        created_at: new Date(Date.now() - 10 * 24 * 3600 * 1000).toISOString()
      }
    ],
    orders: [],
    order_items: [],
    users: [
      {
        id: "u1111111-2222-3333-4444-555555555555",
        name: "سوبر أدمن",
        email: "admin@zouma.com",
        password_hash: defaultAdminPasswordHash,
        role: "super_admin",
        permissions: ["dashboard", "clients", "orders", "products", "profits", "users"],
        created_at: new Date().toISOString()
      },
      {
        id: "u2222222-2222-3333-4444-555555555555",
        name: "أحمد الموظف",
        email: "employee@zouma.com",
        password_hash: defaultAdminPasswordHash,
        role: "employee",
        permissions: ["dashboard", "clients", "orders", "products"],
        created_at: new Date().toISOString()
      }
    ]
  };

  const today = new Date();
  const currentYear = today.getFullYear();

  const o1Id = "o1111111-2222-3333-4444-555555555555";
  const o2Id = "o2222222-2222-3333-4444-555555555555";
  const o3Id = "o3333333-2222-3333-4444-555555555555";

  freshDb.orders = [
    {
      id: o1Id,
      client_id: "c1111111-2222-3333-4444-555555555555",
      status: "DELIVERED",
      date: `${currentYear}-01-10`,
      discount_percentage: 10,
      paid_amount: 594,
      total: 594,
      cost: 380,
      profit: 214,
      discount: 66,
      notes: "توصيل سريع للمنزل",
      created_at: `${currentYear}-01-10T14:30:00Z`
    },
    {
      id: o2Id,
      client_id: "c1111111-2222-3333-4444-555555555555",
      status: "CONFIRMED",
      date: `${currentYear}-02-14`,
      discount_percentage: 0,
      paid_amount: 300,
      total: 480,
      cost: 300,
      profit: 180,
      discount: 0,
      notes: "هدية عيد الحب",
      created_at: `${currentYear}-02-14T10:00:00Z`
    },
    {
      id: o3Id,
      client_id: "c2222222-2222-3333-4444-555555555555",
      status: "DELIVERED",
      date: `${currentYear}-03-05`,
      discount_percentage: 0,
      paid_amount: 430,
      total: 430,
      cost: 240,
      profit: 190,
      discount: 0,
      notes: "مع تغليف شريط ذهبي وبطاقة تهنئة",
      created_at: `${currentYear}-03-05T18:22:00Z`
    }
  ];

  freshDb.order_items = [
    {
      id: "i1111111-1111-1111-1111-111111111111",
      order_id: o1Id,
      product_id: "p1111111-2222-3333-4444-555555555555",
      name: "دبدوب أحمر كبير مخملي",
      price: 250,
      qty: 2
    },
    {
      id: "i1111111-1111-1111-1111-222222222222",
      order_id: o1Id,
      product_id: "p2222222-2222-3333-4444-555555555555",
      name: "صندوق هدايا خشبي محفور",
      price: 160,
      qty: 1
    },
    {
      id: "i2222222-1111-1111-1111-111111111111",
      order_id: o2Id,
      product_id: "p3333333-2222-3333-4444-555555555555",
      name: "سلسلة فضية بتصميم خاص",
      price: 480,
      qty: 1
    },
    {
      id: "i3333333-1111-1111-1111-111111111111",
      order_id: o3Id,
      product_id: "p1111111-2222-3333-4444-555555555555",
      name: "دبدوب أحمر كبير مخملي",
      price: 250,
      qty: 1
    },
    {
      id: "i3333333-1111-1111-1111-222222222222",
      order_id: o3Id,
      product_id: "p4444444-2222-3333-4444-555555555555",
      name: "كوب حراري ذكي مع شاشة حرارة",
      price: 180,
      qty: 1
    }
  ];

  fs.writeFileSync(fallbackDbPath, JSON.stringify(freshDb, null, 2), "utf-8");
  return freshDb;
}

let localStore = initFallbackDb();

function saveLocalStore() {
  fs.writeFileSync(fallbackDbPath, JSON.stringify(localStore, null, 2), "utf-8");
}

// Global Semantic DB Operations
export const db = {
  // CLIENTS Operations
  clients: {
    list: async () => {
      if (isProductionDb) {
        const { data, error } = await supabaseClient
          .from("clients")
          .select("*")
          .order("created_at", { ascending: false });
        if (error) throw error;
        return data;
      } else {
        return [...localStore.clients].sort((a, b) => b.created_at.localeCompare(a.created_at));
      }
    },
    get: async (id) => {
      if (isProductionDb) {
        const { data, error } = await supabaseClient
          .from("clients")
          .select("*")
          .eq("id", id)
          .maybeSingle();
        if (error) throw error;
        return data;
      } else {
        return localStore.clients.find(c => c.id === id) || null;
      }
    },
    getByCode: async (code) => {
      if (isProductionDb) {
        const { data, error } = await supabaseClient
          .from("clients")
          .select("*")
          .eq("client_code", code)
          .maybeSingle();
        if (error) throw error;
        return data;
      } else {
        return localStore.clients.find(c => c.client_code === code) || null;
      }
    },
    create: async (payload) => {
      if (isProductionDb) {
        const { data, error } = await supabaseClient
          .from("clients")
          .insert([payload])
          .select()
          .single();
        if (error) throw error;
        return data;
      } else {
        const newClient = {
          id: crypto.randomUUID(),
          ...payload,
          created_at: new Date().toISOString()
        };
        localStore.clients.push(newClient);
        saveLocalStore();
        return newClient;
      }
    },
    update: async (id, payload) => {
      if (isProductionDb) {
        const { data, error } = await supabaseClient
          .from("clients")
          .update(payload)
          .eq("id", id)
          .select()
          .single();
        if (error) throw error;
        return data;
      } else {
        const idx = localStore.clients.findIndex(c => c.id === id);
        if (idx === -1) return null;
        localStore.clients[idx] = { ...localStore.clients[idx], ...payload };
        saveLocalStore();
        return localStore.clients[idx];
      }
    },
    delete: async (id) => {
      if (isProductionDb) {
        // Since Postgres cascade referenced tables, doing it on API or relying on server.
        // We'll delete directly.
        const { data, error } = await supabaseClient
          .from("clients")
          .delete()
          .eq("id", id)
          .select()
          .maybeSingle();
        if (error) throw error;
        return data;
      } else {
        const matched = localStore.clients.find(c => c.id === id);
        if (!matched) return null;
        localStore.clients = localStore.clients.filter(c => c.id !== id);
        const ordersToDelete = localStore.orders.filter(o => o.client_id === id);
        for (const order of ordersToDelete) {
          localStore.order_items = localStore.order_items.filter(item => item.order_id !== order.id);
        }
        localStore.orders = localStore.orders.filter(o => o.client_id !== id);
        saveLocalStore();
        return matched;
      }
    }
  },

  // PRODUCTS Operations
  products: {
    list: async () => {
      if (isProductionDb) {
        const { data, error } = await supabaseClient
          .from("products")
          .select("*")
          .order("serial", { ascending: true });
        if (error) throw error;
        return data;
      } else {
        return [...localStore.products].sort((a, b) => a.serial - b.serial);
      }
    },
    get: async (id) => {
      if (isProductionDb) {
        const { data, error } = await supabaseClient
          .from("products")
          .select("*")
          .eq("id", id)
          .maybeSingle();
        if (error) throw error;
        return data;
      } else {
        return localStore.products.find(p => p.id === id) || null;
      }
    },
    create: async (payload) => {
      if (isProductionDb) {
        // Let the DB sequence serialize unless not working. Standard insertion without serial specified
        const { data, error } = await supabaseClient
          .from("products")
          .insert([payload])
          .select()
          .single();
        if (error) throw error;
        return data;
      } else {
        const maxSerial = localStore.products.reduce((max, p) => (p.serial > max ? p.serial : max), 1000);
        const newProduct = {
          id: crypto.randomUUID(),
          serial: maxSerial + 1,
          ...payload,
          created_at: new Date().toISOString()
        };
        localStore.products.push(newProduct);
        saveLocalStore();
        return newProduct;
      }
    },
    update: async (id, payload) => {
      if (isProductionDb) {
        const { data, error } = await supabaseClient
          .from("products")
          .update(payload)
          .eq("id", id)
          .select()
          .single();
        if (error) throw error;
        return data;
      } else {
        const idx = localStore.products.findIndex(p => p.id === id);
        if (idx === -1) return null;
        localStore.products[idx] = { ...localStore.products[idx], ...payload };
        saveLocalStore();
        return localStore.products[idx];
      }
    },
    updateStock: async (id, change) => {
      if (isProductionDb) {
        // Need to load and modify transactionally/safely
        const { data: prod, error: fetchErr } = await supabaseClient
          .from("products")
          .select("stock")
          .eq("id", id)
          .single();
        if (fetchErr) throw fetchErr;
        const newStock = Math.max(0, (prod?.stock || 0) + change);
        const { data, error } = await supabaseClient
          .from("products")
          .update({ stock: newStock })
          .eq("id", id)
          .select()
          .single();
        if (error) throw error;
        return data;
      } else {
        const idx = localStore.products.findIndex(p => p.id === id);
        if (idx !== -1) {
          localStore.products[idx].stock = Math.max(0, (localStore.products[idx].stock || 0) + change);
          saveLocalStore();
          return localStore.products[idx];
        }
        return null;
      }
    },
    delete: async (id) => {
      if (isProductionDb) {
        const { data, error } = await supabaseClient
          .from("products")
          .delete()
          .eq("id", id)
          .select()
          .maybeSingle();
        if (error) throw error;
        return data;
      } else {
        const matched = localStore.products.find(p => p.id === id);
        if (!matched) return null;
        localStore.products = localStore.products.filter(p => p.id !== id);
        saveLocalStore();
        return matched;
      }
    }
  },

  // ORDERS Operations
  orders: {
    list: async () => {
      if (isProductionDb) {
        const { data, error } = await supabaseClient
          .from("orders")
          .select("*, clients(name, client_code)")
          .order("created_at", { ascending: false });
        if (error) throw error;
        return (data || []).map(o => ({
          ...o,
          client_name: o.clients ? o.clients.name : "عميل محذوف",
          client_code: o.clients ? o.clients.client_code : ""
        }));
      } else {
        return localStore.orders.map(o => {
          const client = localStore.clients.find(c => c.id === o.client_id);
          return {
            ...o,
            client_name: client ? client.name : "عميل محذوف",
            client_code: client ? client.client_code : ""
          };
        }).sort((a, b) => b.created_at.localeCompare(a.created_at));
      }
    },
    get: async (id) => {
      if (isProductionDb) {
        const { data: order, error: orderErr } = await supabaseClient
          .from("orders")
          .select("*")
          .eq("id", id)
          .maybeSingle();
        if (orderErr) throw orderErr;
        if (!order) return null;

        const { data: client } = await supabaseClient
          .from("clients")
          .select("name, client_code, phone")
          .eq("id", order.client_id)
          .maybeSingle();

        const { data: items } = await supabaseClient
          .from("order_items")
          .select("*")
          .eq("order_id", id);

        return {
          ...order,
          client: client || null,
          items: items || []
        };
      } else {
        const order = localStore.orders.find(o => o.id === id);
        if (!order) return null;
        const client = localStore.clients.find(c => c.id === order.client_id) || null;
        const items = localStore.order_items.filter(i => i.order_id === id);
        return {
          ...order,
          client,
          items
        };
      }
    },
    create: async (orderPayload, items) => {
      if (isProductionDb) {
        // Insert order
        const { data: order, error: orderErr } = await supabaseClient
          .from("orders")
          .insert([orderPayload])
          .select()
          .single();
        if (orderErr) throw orderErr;

        // Insert items
        const rawItems = items.map(item => ({
          order_id: order.id,
          product_id: item.product_id || null,
          name: item.name,
          price: item.price,
          qty: item.qty
        }));

        const { error: itemsErr } = await supabaseClient
          .from("order_items")
          .insert(rawItems);
        if (itemsErr) throw itemsErr;

        // Inventory deductions if active
        if (orderPayload.status !== "CANCELLED") {
          for (const item of items) {
            if (item.product_id) {
              await db.products.updateStock(item.product_id, -item.qty);
            }
          }
        }

        return order;
      } else {
        const orderId = crypto.randomUUID();
        const createdOrder = {
          id: orderId,
          ...orderPayload,
          created_at: new Date().toISOString()
        };

        const createdItems = items.map(item => {
          const itemObj = {
            id: crypto.randomUUID(),
            order_id: orderId,
            product_id: item.product_id || null,
            name: item.name,
            price: item.price,
            qty: item.qty
          };
          localStore.order_items.push(itemObj);
          return itemObj;
        });

        localStore.orders.push(createdOrder);

        // Deduct inventory
        if (orderPayload.status !== "CANCELLED") {
          for (const item of items) {
            if (item.product_id) {
              const prodIdx = localStore.products.findIndex(p => p.id === item.product_id);
              if (prodIdx !== -1) {
                localStore.products[prodIdx].stock = Math.max(0, (localStore.products[prodIdx].stock || 0) - item.qty);
              }
            }
          }
        }

        saveLocalStore();
        return {
          ...createdOrder,
          items: createdItems
        };
      }
    },
    update: async (id, payload) => {
      if (isProductionDb) {
        const { data, error } = await supabaseClient
          .from("orders")
          .update(payload)
          .eq("id", id)
          .select()
          .single();
        if (error) throw error;
        return data;
      } else {
        const idx = localStore.orders.findIndex(o => o.id === id);
        if (idx === -1) return null;
        localStore.orders[idx] = { ...localStore.orders[idx], ...payload };
        saveLocalStore();
        return localStore.orders[idx];
      }
    },
    getOrderItems: async (orderId) => {
      if (isProductionDb) {
        const { data, error } = await supabaseClient
          .from("order_items")
          .select("*")
          .eq("order_id", orderId);
        if (error) throw error;
        return data;
      } else {
        return localStore.order_items.filter(i => i.order_id === orderId);
      }
    },
    delete: async (id) => {
      if (isProductionDb) {
        const { data, error } = await supabaseClient
          .from("orders")
          .delete()
          .eq("id", id)
          .select()
          .maybeSingle();
        if (error) throw error;
        return data;
      } else {
        const matched = localStore.orders.find(o => o.id === id);
        if (!matched) return null;
        localStore.orders = localStore.orders.filter(o => o.id !== id);
        localStore.order_items = localStore.order_items.filter(i => i.order_id !== id);
        saveLocalStore();
        return matched;
      }
    }
  },

  // USERS Operations
  users: {
    list: async () => {
      if (isProductionDb) {
        const { data, error } = await supabaseClient
          .from("users")
          .select("id, name, email, role, permissions, created_at")
          .order("created_at", { ascending: false });
        if (error) throw error;
        return data;
      } else {
        return localStore.users.map(({ id, name, email, role, permissions, created_at }) => ({
          id, name, email, role, permissions, created_at
        }));
      }
    },
    getByEmail: async (email) => {
      try {
        const cleanEmail = email.toLowerCase().trim();
        if (isProductionDb) {
          const { data, error } = await supabaseClient
            .from("users")
            .select("*")
            .eq("email", cleanEmail)
            .maybeSingle();
          if (error) throw error;
          return data;
        } else {
          return localStore.users.find(u => u.email.toLowerCase() === cleanEmail) || null;
        }
      } catch (err) {
        console.error("Error inside getUserByEmail:", err);
        return null;
      }
    },
    get: async (id) => {
      if (isProductionDb) {
        const { data, error } = await supabaseClient
          .from("users")
          .select("*")
          .eq("id", id)
          .maybeSingle();
        if (error) throw error;
        return data;
      } else {
        return localStore.users.find(u => u.id === id) || null;
      }
    },
    create: async (payload) => {
      if (isProductionDb) {
        const { data, error } = await supabaseClient
          .from("users")
          .insert([payload])
          .select()
          .single();
        if (error) throw error;
        return data;
      } else {
        const newUser = {
          id: crypto.randomUUID(),
          ...payload,
          created_at: new Date().toISOString()
        };
        localStore.users.push(newUser);
        saveLocalStore();
        return newUser;
      }
    },
    update: async (id, payload) => {
      if (isProductionDb) {
        const { data, error } = await supabaseClient
          .from("users")
          .update(payload)
          .eq("id", id)
          .select()
          .single();
        if (error) throw error;
        return data;
      } else {
        const idx = localStore.users.findIndex(u => u.id === id);
        if (idx === -1) return null;
        localStore.users[idx] = { ...localStore.users[idx], ...payload };
        saveLocalStore();
        return localStore.users[idx];
      }
    },
    delete: async (id) => {
      if (isProductionDb) {
        const { data, error } = await supabaseClient
          .from("users")
          .delete()
          .eq("id", id)
          .select()
          .maybeSingle();
        if (error) throw error;
        return data;
      } else {
        const matched = localStore.users.find(u => u.id === id);
        if (!matched) return null;
        localStore.users = localStore.users.filter(u => u.id !== id);
        saveLocalStore();
        return matched;
      }
    }
  }
};
